import requests
import json

# Replace with your own Discord API token
api_token = "YOUR_API_TOKEN"

# Function to get user data from the Discord API
def get_user_data(username):
    url = f"https://discord.com/api/v9/users/{username}"
    headers = {"Authorization": f"Bearer {api_token}"}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return json.loads(response.content)
    else:
        return None

# Function to get user IP address from user data
def get_user_ip(user_data):
    if user_data:
        return user_data["ip"]
    else:
        return None

# Main function
def main():
    username = input("Enter the username: ")
    user_data = get_user_data(username)
    if user_data:
        ip_address = get_user_ip(user_data)
        print(f"IP address: {ip_address}")
    else:
        print("Failed to get user data")

if __name__ == "__main__":
    main()